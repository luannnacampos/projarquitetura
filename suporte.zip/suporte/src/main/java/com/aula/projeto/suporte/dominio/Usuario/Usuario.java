package com.aula.projeto.suporte.dominio.Usuario;

import jakarta.persistence.Entity;

@Entity
public class Usuario extends Pessoa {

    private String nome;

    public Usuario(String nome, String email, String telefone) {
        super( nome, email, telefone);
    }

    private Usuario getInstance(){
        if(this.usuario==null) {
            this.usuario = new Usuario();
        }
        return this.usuario;
    }
    public Usuario(){}
}
